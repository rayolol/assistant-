import './App.css';
//import Component from './chatbox_input.jsx';
import Page from "./app/page.tsx";

function App() {
  
  return (
    <Page/>
  );

}
export default App;
