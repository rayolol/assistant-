"""Core module for the chatbot application"""
